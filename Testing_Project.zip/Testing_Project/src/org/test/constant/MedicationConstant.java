package org.test.constant;

import org.test.contract.ExceptionCode;

public class MedicationConstant {
	private MedicationConstant() {}
	
	public enum MedicationErrorCode implements ExceptionCode {
		DUPLICATE_RX_FOUND("Duplicate Rx found");
		
		private String message;
		
		MedicationErrorCode(String message) {
			this.message = message;
		}
		
		@Override
		public String getMessage() {
			return this.message;
		}
	}
	
	public enum OtherErrorCode {
		OTHER1,
		OTHER2;
	}
}
