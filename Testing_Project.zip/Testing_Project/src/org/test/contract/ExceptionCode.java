package org.test.contract;

public interface ExceptionCode {
	public String getMessage();
}
