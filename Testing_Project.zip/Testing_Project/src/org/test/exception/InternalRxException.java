package org.test.exception;

import org.test.contract.ExceptionCode;

public class InternalRxException extends Exception {

	private static final long serialVersionUID = 8506833487913280766L;

	ExceptionCode exceptionCode;
	
	public <T extends ExceptionCode> InternalRxException(T exceptionCode) {
		super(exceptionCode.getMessage());
		this.exceptionCode = exceptionCode;
	}
	
	public <T extends ExceptionCode> InternalRxException(T exceptionCode, String message) {
		super(message);
		this.exceptionCode = exceptionCode;
	}
	
	public <T extends ExceptionCode> InternalRxException(T exceptionCode, Throwable arg1) {
		super(exceptionCode.getMessage(), arg1);
		this.exceptionCode = exceptionCode;
	}
	
	public <T extends ExceptionCode> InternalRxException(T exceptionCode, String message, Throwable arg1) {
		super(message, arg1);
		this.exceptionCode = exceptionCode;
	}

	@SuppressWarnings("unchecked")
	public <T extends ExceptionCode> T getExceptionCode() {
		return ((T) exceptionCode);
	}
}
