package org.test;

import org.test.constant.MedicationConstant.MedicationErrorCode;
import org.test.constant.MedicationConstant.OtherErrorCode;
import org.test.exception.InternalRxException;

public class Test {
	public static void main(String[] args) {
		try {
			process(1);
		} catch (InternalRxException e) {
			MedicationErrorCode errorCode = e.getExceptionCode();
			switch (errorCode) {
				case DUPLICATE_RX_FOUND:
					break;
				default:
					break;
			}
		}
	}
	
	public static void process(int i) throws InternalRxException {
		if (i == 0) {
			throw new InternalRxException(MedicationErrorCode.DUPLICATE_RX_FOUND);
		} else if (i > 0) {
			throw new InternalRxException(OtherErrorCode.OTHER1);
		}
	}
}
